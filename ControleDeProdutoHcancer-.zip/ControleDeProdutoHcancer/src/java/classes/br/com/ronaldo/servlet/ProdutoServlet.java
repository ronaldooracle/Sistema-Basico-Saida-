package classes.br.com.ronaldo.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import classes.br.com.ronaldo.dao.ProdutoDAO;
import classes.br.com.ronaldo.entidade.Produto;

@WebServlet("/ProdutoServlet")
public class ProdutoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        String acao = request.getParameter("acao");
        String destino = "sucesso.jsp";
        String mensagem = "";
        List<Produto> lista = new ArrayList<>();

        Produto produto = new Produto();
        ProdutoDAO dao = new ProdutoDAO();

        try {

            if (!acao.equalsIgnoreCase("Listar")) {
                produto.setMatricula(Long.parseLong(request.getParameter("matricula")));
                produto.setNome(request.getParameter("nome"));
                produto.setTelefone(request.getParameter("telefone"));
                produto.setProd(request.getParameter("prod"));

                try {
                    DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                    produto.setDataCadastro(df.parse(request.getParameter("dataCadastro")));
                } catch (Exception e) {
                    produto.setDataCadastro(new Date());
                }

            }
            
            if (acao.equalsIgnoreCase("Incluir")) {
                if (dao.existe(produto)) {
                    mensagem = "Matrícula informada já existe!";
                } else {
                    dao.inserir(produto);
                }
            }  else if (acao.equalsIgnoreCase("Excluir")) {
                dao.excluir(produto);
            } else if (acao.equalsIgnoreCase("Alterar")) {
                dao.alterar(produto);
                
                
            }else if (acao.equalsIgnoreCase("Consultar")) {
                request.setAttribute("produto", produto);
                produto = dao.consultar(produto);
                destino = "ConsultaProduto.jsp";
            }
        } catch (Exception e) {
            mensagem += e.getMessage();
            destino = "erro.jsp";
            e.printStackTrace();
        }

        if (mensagem.length() == 0) {
            mensagem = "Gerado";
        } else {
            destino = "erro.jsp";
        }

        lista = dao.listar();
        request.setAttribute("listaProduto", lista);
        request.setAttribute("mensagem", mensagem);

        RequestDispatcher rd = request.getRequestDispatcher(destino);
        rd.forward(request, response);
    }
}
