package classes.br.com.ronaldo.dao;

import br.com.ronaldo.dao.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import classes.br.com.ronaldo.entidade.Produto;

/**
 * 
 * Classe de Persistência de dados dos objetos de Produto
 é "filha" da Classe DAO. 
 *
 */

public class ProdutoDAO extends DAO {

		
	public void excluir(Produto produto) {
		try {
			Connection conexao = getConexao();
			PreparedStatement hcan = conexao
					.prepareStatement("Delete from	produtos where matricula = ? ");
			hcan.setLong(1, produto.getMatricula());
			hcan.execute();
			hcan.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
        	public void alterar(Produto produto) {
		try {
			Connection conexao = getConexao();

			PreparedStatement hcan = conexao
					.prepareStatement("update produtos SET nome = ?, telefone = ?, prod = ?, datacadastro = ?"
                                                + " WHERE matricula = ? ");
			hcan.setString(1, produto.getNome());
			hcan.setString(2, produto.getTelefone());
			hcan.setString(3, produto.getProd());
			hcan.setDate(4, new java.sql.Date(produto.getDataCadastro().getTime()));
			hcan.setLong(5, produto.getMatricula());
			hcan.execute();
			hcan.close();
			conexao.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean existe(Produto produto) {
		boolean achou = false;
		try {
			Connection conexao = getConexao();
			PreparedStatement hcan = conexao
					.prepareStatement("Select * from produtos where matricula =	?");
			hcan.setLong(1, produto.getMatricula());
			ResultSet rs = hcan.executeQuery();
			if (rs.next()) {
				achou = true;
			}
			hcan.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return achou;
	}

	public void inserir(Produto produto) {
		try {
			Connection conexao = getConexao();
			PreparedStatement hcan = conexao
					.prepareStatement("Insert into	produtos (matricula, nome, telefone, prod, datacadastro) values	(?,?,?,?,?)");
			hcan.setLong(1, produto.getMatricula());
			hcan.setString(2, produto.getNome());
			hcan.setString(3, produto.getTelefone());
			hcan.setString(4, produto.getProd());
			hcan.setDate(5, new java.sql.Date(produto.getDataCadastro()
					.getTime()));
			hcan.execute();
			hcan.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<Produto> listar() {
		List<Produto> lista = new ArrayList<>();
		try {
			Connection conexao = getConexao();
			Statement hcan = conexao.createStatement();
			ResultSet rs = hcan.executeQuery("Select * from produtos");
			while (rs.next()) {
				Produto produto = new Produto();
				produto.setMatricula(rs.getLong("matricula"));
				produto.setNome(rs.getString("nome"));
				produto.setTelefone(rs.getString("telefone"));
				produto.setProd(rs.getString("prod"));
				produto.setDataCadastro(new java.util.Date(rs.getDate("datacadastro").getTime()));
				lista.add(produto);
			}
			hcan.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lista;
	}

	public Produto consultar(Produto produto) {
		try {
			Connection conexao = getConexao();
			PreparedStatement hcan = conexao
					.prepareStatement("Select * from Produtos where matricula =	?");
			hcan.setLong(1, produto.getMatricula());
			ResultSet rs = hcan.executeQuery();
			if (rs.next()) {
				produto.setMatricula(rs.getLong("matricula"));
				produto.setNome(rs.getString("nome"));
				produto.setTelefone(rs.getString("telefone"));
				produto.setProd(rs.getString("prod"));
				produto.setDataCadastro(new java.util.Date(rs.getDate("datacadastro").getTime()));
			}
			hcan.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return produto;
	}
}