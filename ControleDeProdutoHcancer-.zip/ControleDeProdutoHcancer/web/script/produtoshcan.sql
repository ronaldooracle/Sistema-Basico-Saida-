
CREATE DATABASE postgres
  WITH OWNER = postgres
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'Portuguese_Brazil.1252'
       LC_CTYPE = 'Portuguese_Brazil.1252'
       CONNECTION LIMIT = -1;




CREATE TABLE  IF NOT EXISTS produtos(
  matricula bigint NOT NULL,  
  nome character varying(255),
  telefone character varying(255),  
  prod character varying(255),
  datacadastro date,
  CONSTRAINT tbaluno_pkey PRIMARY KEY (matricula)
);
